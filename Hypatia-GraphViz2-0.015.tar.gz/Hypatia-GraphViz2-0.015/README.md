Hypatia::GraphViz2
==============

Hypatia Bindings for [GraphViz2](https://metacpan.org/module/GraphViz2). Look at [the documentation](https://metacpan.org/module/Hypatia::GraphViz2) for more details.
